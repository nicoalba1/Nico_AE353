function [ output ] = lab1_bodypov( mocap )

% SPEED UP CODE BY ONLY WORKING WITH MOCAP DATA AT 20 HZ INSTEAD OF 100 HZ
mocap = mocap(:,1:5:end);

t = mocap(2,:);
dt = mocap(2,2:end) - mocap(2,1:end-1);

% CREATE WORLD OBJECTS
load('world.mat');  % this will load variables:   w0  wsz  wcolors

% CREATE A QUADROTOR
load('quadmodel.mat');  % this will load variables:  p1   faces   colors

% SETUP THE PLOT
clf;
axis([-4 4 -4 4 -0.1 3.5]);
axis equal;
hold on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE HERE TO COMPUTE p2 and w2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ROTATE FROM BODY FRAME TO MATLAB PLOT FRAME
p2 = p1;
% ROTATE FROM WORLD FRAME TO MATLAB PLOT FRAME
w2 = w0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hw = scatter3(w2(1,:), w2(2,:), w2(3,:), wsz, wcolors,'filled');
plot3(0,0,0,'k.','markersize',16);
h = patch('Vertices',p2','Faces',faces,...
          'CData',colors,'FaceColor','flat');
hTitle = title(sprintf('t = %4.2f',0));
lighting flat
light('Position',[0 -2 -1])
light('Position',[0 -2 1])
xlabel('x'); ylabel('y'); zlabel('z');
drawnow;
pause(0.5);

% ANIMATE THE RESULTS
i = 1;
tic;
while (i<length(t)-1)
    if (toc > dt(i))
        tic;
        i = i+1;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % YOUR CODE HERE TO COMPUTE w1 and w2
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % ROTATE FROM WORLD TO BODY FRAME
        w1 = w0;
        
        % ROTATE FROM BODY FRAME TO MATLAB DISPLAY FRAME
        w2 = w1;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        % UPDATE GRAPHICS OBJECT VERTICES
        set(hw,'XData',w2(1,:), 'YData',w2(2,:), 'ZData',w2(3,:));
        set(hTitle,'string',sprintf('t = %4.2f',t(i)));
        drawnow;
    end
end

end  %%% END lab1_bodypov_soln()


function [R] = rotationMatrixFromEulerAngles(phi, theta, psi)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE HERE TO COMPUTE ROTATION MATRIX FROM ZYX Euler Angles
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

R = eye(3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
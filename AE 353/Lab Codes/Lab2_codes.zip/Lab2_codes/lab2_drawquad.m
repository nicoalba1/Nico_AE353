function [output] = lab2_drawquad()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE HERE TO COMPUTE LOAD YOUR DATA FILE
% THAT YOU COLLECTED FROM THE TEST STAND DURING LAB.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('blah.mat');  % this should load the variables that you recorded containing: time and theta_y

% COMPUTE TIME IN SECONDS, SHIFTED SO THAT TIME STARTS AT 0
% t = ???

% FIND "delta t" BETWEEN EACH SAMPLE MEASUREMENT.
% dt = ??? 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% CREATE A QUADROTOR
load('quadmodel.mat');  % This will provide variables p1, faces, colors


% SETUP THE PLOT
clf;
set(gcf,'Renderer','zbuffer');
axis([-1 1 -1 1 -0.5 1.5]);
axis equal;
hold on;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE HERE TO COMPUTE p2 TO INITIALIZE THE DRAWING
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p0 = p1;
p2 = p0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

plot3(0,0,0,'k.','markersize',16);
h = patch('Vertices',p2','Faces',faces,...
          'CData',colors,'FaceColor','flat');
hTitle = title(sprintf('t = %4.2f',0));
lighting flat
light('Position',[0 -2 -1])
light('Position',[0 -2 1])
xlabel('x'); ylabel('y'); zlabel('z');
drawnow;
pause(0.5);

% ANIMATE THE RESULTS
i = 1;
tic;
while (i<length(t)-1)
    if (toc > dt(i))
        tic;
        i = i+1;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % YOUR CODE HERE TO COMPUTE p2   it is easiest to first compute p0
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        p0 = p1;
        p2 = p0;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        

        % UPDATE GRAPHICS OBJECT VERTICES
        set(h,'Vertices',p2');
        set(hTitle,'string',sprintf('t = %4.2f',t(i)));
        drawnow;
    end
end

end  %%% END lab2_drawquad()



function R = rotation(phi, theta, psi)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE HERE TO COMPUTE ROTATION MATRIX R_1^0 FROM ZYX Euler Angles
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

R = eye(3,3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

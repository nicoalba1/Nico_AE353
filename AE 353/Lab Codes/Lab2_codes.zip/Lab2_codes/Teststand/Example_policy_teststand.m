function u = Example_policy_teststand(t,x)
%
% u = Example_policy_teststand(t,x)
%
% inputs:
%   t -- time in seconds
%   x -- state vector [ theta; thetadot ]
%
% outputs:
%   u -- control vector [u], representing applied pitch moment
%

% CREATE YOUR CONTROLLER HERE

u = 0;

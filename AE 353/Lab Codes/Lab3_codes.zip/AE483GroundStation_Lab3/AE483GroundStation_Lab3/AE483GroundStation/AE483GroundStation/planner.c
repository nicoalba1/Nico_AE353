//
// AE483GroundStation
// David Hanley
//
// planner.c
// This file contains all functions for planning. The most basic example
// would be to hold position at some desired (x,y,z,yaw).
//





/*----------------------------------------------------------------------*/
/*------------------------------ Preamble ------------------------------*/
/*----------------------------------------------------------------------*/

/*--------------- Includes ---------------*/

//system
#include <math.h>

//planner
#include "planner.h"

/*------------- End Includes -------------*/

/*----------------------------------------------------------------------*/
/*------------------------------ Preamble ------------------------------*/
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
/*----------------------------- Functions ------------------------------*/
/*----------------------------------------------------------------------*/
/*--------------- Quat2Euler/Euler2Quat ---------------*/
void Planner_Quat2Euler_f(Quat_f *quat_param, Euler_f *euler_param)
{
	//variables
	float sqw = quat_param->qw*quat_param->qw;
	float sqx = quat_param->qx*quat_param->qx;
	float sqy = quat_param->qy*quat_param->qy;
	float sqz = quat_param->qz*quat_param->qz;
	float unit = sqx + sqy + sqz + sqw; // if normalised is one, otherwise is correction factor

	//singularity tests
	float test = quat_param->qx*quat_param->qy + quat_param->qz*quat_param->qw;
	if (test > 0.499*unit) { // singularity at north pole
		euler_param->ty = 2 * atan2f(quat_param->qx, quat_param->qw);
		euler_param->tz = PI_f / 2;
		euler_param->tx = 0;
		return;
	}
	if (test < -0.499*unit) { // singularity at south pole
		euler_param->ty = -2 * atan2f(quat_param->qx, quat_param->qw);
		euler_param->tz = -PI_f / 2;
		euler_param->tx = 0;
		return;
	}

	//no singularity
	euler_param->ty = atan2f(2 * quat_param->qy*quat_param->qw - 2 * quat_param->qx*quat_param->qz, sqx - sqy - sqz + sqw);
	euler_param->tz = asinf(2 * test / unit);
	euler_param->tx = atan2f(2 * quat_param->qx*quat_param->qw - 2 * quat_param->qy*quat_param->qz, -sqx + sqy - sqz + sqw);
}
/*------------- End Quat2Euler/Euler2Quat -------------*/

/*----- MakeState -----*/
void Planner_MakeState6f_PosQuat(State6_f *state_param, Pos_f *pos_param, Quat_f *quat_param)
{
	state_param->Pos.x = pos_param->x;
	state_param->Pos.y = pos_param->y;
	state_param->Pos.z = pos_param->z;
	Planner_Quat2Euler_f(quat_param, &(state_param->Ori));
}
/*--- End MakeState ---*/
/*-- Potential Field --*/


int switchcount = 0;
int firsttime = 1;
void PotentialField(State6_f state_param,State6_f ObstCurrent, PosYaw_f *dGoal, float time,int PotFlag)
{
	/*---------- Simple Desired Position Set ------------------*/

	dGoal->Pos.x = 0.0;
	dGoal->Pos.y = 0.0;
	dGoal->Pos.z = -0.8;
	dGoal->Tz = 0.0;

	/*-------- End Simple Desired Position Set ----------------*/
}
/* End Potential Field */
/*----------------------------------------------------------------------*/
/*--------------------------- End Functions ----------------------------*/
/*----------------------------------------------------------------------*/
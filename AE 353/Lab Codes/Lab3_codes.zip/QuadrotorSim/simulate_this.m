close all
clear
clc

% Initial conditions
tspan=[0 5]; dt_inner=0.001; dt_outer=0.01;
x0=zeros(12,1);
x0(1)=2;

%set up parameters
params.m = 0.6891;  params.g = 9.81;    params.J = [0.004093, 0, 0; 0, 0.003944, 0; 0, 0, 0.007593];
params.dt_inner = dt_inner; params.dt_outer = dt_outer;

%% Simulation: No changes here
N_steps = range(tspan)/params.dt_inner + 1;
X = nan(N_steps,12);
x = x0;
n_step = 1;
X(n_step,:) = x';

for t = tspan(1):params.dt_inner:(tspan(2)-params.dt_inner)
    
    if(mod(t,params.dt_outer)==0)
        u_outer = Outer(t,x,params);
    end
    
    u = Inner(t,x,u_outer,params);
    
    xdot = Quad_EOM(x,u,params);
    x = x + xdot*params.dt_inner;
    
    n_step = n_step + 1;
    X(n_step,:) = x';
    
end

T = tspan(1):params.dt_inner:tspan(2);
plot_basic
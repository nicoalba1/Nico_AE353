function u=Outer(t,x,params)

%main purpose of Outer is to observe position errors and compute desired
%roll, pitch, yaw and thrust

persistent K1 K2 K3
u_nom=[0;0;0;params.m*params.g];

if isempty(K1)

    %LQR CONTROLLER X-position

    %LQR CONTROLLER Y-POSITION
    
    %LQR CONTROLLER Z-position

    %print out gains
end

%compute desired roll, pitch, yaw and thrust

% delta_u=[delta_theta3_des;delta_theta2_des;delta_theta1_des;delta_u4];
delta_u=[roll_des;pitch_des;yaw_des;delta_thrust];

%%% RETURN OUTER LOOP CONTROL VECTOR
u=u_nom + delta_u;
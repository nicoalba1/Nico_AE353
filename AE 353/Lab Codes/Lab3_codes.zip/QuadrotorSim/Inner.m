function u=Inner(t,x,u_outer,params)

% The main purpose of the inner loop controller is to regulate attitude.

persistent Kroll Kpitch Kyaw
% CONTROL

u=zeros(4,1);

%defining desired angles
a=u_outer(3);   %yaw
b=u_outer(2);   %pitch
c=u_outer(1);   %roll


if isempty(Kroll)
    %LQR CONTROLLER ROLL(THETA3)
    
    %LQR CONTROLLER PITCH(THETA2)
    
    %LQR CONTROLLER YAW(THETA1)
    
end

%compute roll, pitch, yaw torques and thrust
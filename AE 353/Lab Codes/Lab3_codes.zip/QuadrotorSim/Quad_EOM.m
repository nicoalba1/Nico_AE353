function f=Quad_EOM(x,u,params)
%
% x: state vector [x;y;z;theta_1;theta_2;theta_3;vx;vy;vz;r;q;p]
%
%         NOTE: theta_3 = roll, theta_2 = pitch, theta_1 = yaw
%               p = roll rate,  q = pitch rate,  r = yaw rate
%
% u: control vector [u1, u2, u3, u4] == roll, pitch, and yaw torque, and thrust

%f = xdot = h(x,u);
f=zeros(12,1);

%compute f here
u1 and u2 offsets
0.0
0.0